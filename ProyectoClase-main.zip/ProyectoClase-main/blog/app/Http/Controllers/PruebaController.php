<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
class PruebaController extends Controller
{
public function prueba2(){
    return "Estoy dentro de PruebaController ;D";
}
}