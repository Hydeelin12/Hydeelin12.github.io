<?php
echo ("Estoy en la vista");
?>
